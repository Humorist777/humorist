<?php
use \MaxieSystems as MS;
class DollyForms extends MSFieldSet
{
	protected function Action(...$args)
	 {
		$conf = new MS\FileSystemStorage('storage/fs_config.php', ['readonly' => true, 'root' => MSSE_INC_DIR]);
		$id = str_replace('fs_', '', $this->GetId());
		if(isset($conf->$id)) $c = $conf->$id;
		else throw new EFSAction('Не настроена конфигурация.');
		$empty = true;
		$mail = new MSMail();
		$text = $this->ReplaceItem('__dolly_timestamp', date('Y.m.d H:i:s'), $c->template);
		$text = $this->ReplaceItem('__dolly_ip', MSConfig::GetIP(), $text);
		$i = 0;
		foreach($this as $n => $fld)
		 {
			if($fld->object instanceof \MSFieldSet\IFile)
			 {
				$upl = new StreamUploader($fld->input_name);
				if($file = $upl->LoadFile())
				 {
					$mail->AddFileContent($file['data'], $file['name']);
					$empty = false;
				 }
			 }
			else
			 {
				$v = trim($args[$i]);
				$text = $this->ReplaceItem($c->fields[$n][0], $v, $text);
				if('' !== $v) $empty = false;
			 }
			++$i;
		 }
		if($empty) throw new EFSAction('Нельзя отправить пустую форму! Заполните хотя бы одно поле.');
		if(1)// включена фильтрация: проверка наличия HTML.
		 {
			if(preg_match_all('/<([^\s>]+)(.*?)>((.*?)<\/\1>)?|(?<=^|>)(.+?)(?=$|<)/i', $text, $result, PREG_OFFSET_CAPTURE)) throw new EFSAction('Нельзя отправить текст с HTML-разметкой!');
		 }
		$fname = MSSE_INC_DIR.'/storage/fs_stoplist.php';
		if($stoplist = MaxieSystems\File::LoadArray($fname))// включена фильтрация: проверка по словарю.
		 {
			$data = preg_split("/[\s,]*\\\"([^\\\"]+)\\\"[\s,]*|" . "[\s,]*'([^']+)'[\s,]*|" . "[\s,]+/u", $text, 0, PREG_SPLIT_OFFSET_CAPTURE);
			foreach($data as list($word, $pos))
			 {
				$w = str_replace(['.', '?', '!', '«', '»'], '', $word);// это вместо trim, поскольку trim некорректно работает с utf: при обрезке кавычек («») бывают "битые" символы // $w = trim($word, '.?!');//«»
				if(mb_strlen($w, 'utf-8') <= 2) continue;
				if(false !== strpos($w, '<')) continue;
				if(false !== strpos($w, '>')) continue;
				foreach($stoplist as $stopword) if($w === $stopword || mb_strtolower($w, 'utf-8') === $stopword) throw new EFSAction('Сообщение похоже на спам.');
			 }
		 }
		$mail->SetFrom($c->from)->SetTo($c->email)->SetSubject($c->subject)->SetText($text)->Send();
		$fname = MSSE_INC_DIR.'/storage/fs_messages.php';
		$orders = MS\File::LoadArray($fname, $e);
		// $orders = [];
		// $fname = DOCUMENT_ROOT.'/orders.txt';
		// if(file_exists($fname))
		 // {
			// $file = file_get_contents($fname);
			// $orders = unserialize($file);
		 // }
		$orders[] = array('date'    => date('Y-m-d'),
						  'content' => $text,
						  'status'  => 'in_work');
		// file_put_contents($fname, serialize($orders));
		MS\File::SaveArray($fname, $orders);
		if($c->async_response || $c->async_headers)
		 {
			if($c->async_headers) foreach($c->async_headers as $hdr) header($hdr);
			die($c->async_response);
		 }
	 }

	private function ReplaceItem($n, $v, $text) { return str_replace('{'.$n.'}', $v, $text); }
}
?>