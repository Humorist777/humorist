<?php
return array (
  'language' => 'ru',
);
?>